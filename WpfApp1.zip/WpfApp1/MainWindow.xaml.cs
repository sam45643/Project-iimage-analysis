﻿// MainWindow.xaml.cs

//using Azure.AI.Vision.ImageAnalysis.Models;
using Microsoft.Win32;
using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using Azure;
using Azure.AI.Vision.ImageAnalysis;

namespace ImageAnalysisApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void AnalyzeImageButton_Click(object sender, RoutedEventArgs e)
        {
            string imageUrl = ImageUrlTextBox.Text.Trim();
            if (!Uri.IsWellFormedUriString(imageUrl, UriKind.Absolute))
            {
                MessageBox.Show("Please enter a valid image URL or browse for a file.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            await AnalyzeImage(new Uri(imageUrl));
        }

        private async void BrowseFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp|All Files|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                await AnalyzeImage(new Uri(openFileDialog.FileName));
            }
        }

        private async Task AnalyzeImage(Uri imageUri)
        {
            // Replace these with your actual endpoint URL and subscription key
            string endPoint = "https://new333.cognitiveservices.azure.com/";
            string key = "800157e6cf96432a8958603d45173bed";

            // Connect to Azure Computer Vision
            ImageAnalysisClient client = new ImageAnalysisClient(new Uri(endPoint), new AzureKeyCredential(key));

            // Analyze the image
            ImageAnalysisResult result = client.Analyze(imageUri,
                VisualFeatures.Caption | VisualFeatures.DenseCaptions | VisualFeatures.Tags | VisualFeatures.Read | VisualFeatures.Objects,
                new ImageAnalysisOptions { GenderNeutralCaption = true });

            // Display the results
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Image Analysis Results\n");

            // Caption
            sb.AppendLine("Caption: " + result.Caption.Text + "\n");

            // Dense Captions
            sb.AppendLine("Dense Captions:");
            foreach (var dc in result.DenseCaptions.Values)
            {
                sb.AppendLine(dc.Text);
            }
            sb.AppendLine();

            // Tags
            sb.AppendLine("Tags:");
            foreach (var t in result.Tags.Values)
            {
                sb.AppendLine(t.Name + " (" + t.Confidence + ")");
            }
            sb.AppendLine();

            // Read Text
            //sb.AppendLine("Read Text:");
            //foreach (var rt in result.ReadResults.Values)
            //{
              //  foreach (var line in rt.Lines)
                //{
                  //  sb.AppendLine(line.Text);
                //}
            //}
            //sb.AppendLine();

            // Objects
            sb.AppendLine("Objects:");
            foreach (var o in result.Objects.Values)
            {
                sb.AppendLine("- " + string.Join(", ", o.Tags.Select(t => t.Name)));
            }
            sb.AppendLine();

            // People
            sb.AppendLine("People:");
            foreach (var person in result.People.Values)
            {
                sb.AppendLine("- " + person.BoundingBox);
            }

            ResultsTextBlock.Text = sb.ToString();
        }
    }
}